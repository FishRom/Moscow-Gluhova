from flask import Flask, url_for

app = Flask(__name__)


@app.route('/carousel')
def image():
    return """<!doctype html>
<html lang="ru">
<head>
    <title>Подключение Bootstrap 4 к HTML странице</title>
    <meta charset="utf-8">
  <style>
h1 {
    text-align:center;
}

.slideshow {
  width: 900px;
  height: 600px;
  position: relative;
  overflow: hidden;
  background: #000;
  margin: 0 auto;
}
.slideshow-item {
  width: 100%;
  height: 100%;
  position: absolute;
  opacity: 0;
  animation: move 15s infinite;
  pointer-events: none;
}
.slideshow-item:nth-child(1),
.slideshow-item:nth-child(1) img {
  animation-delay: 0;
}
.slideshow-item:nth-child(2),
.slideshow-item:nth-child(2) img {
  animation-delay: 5s;
}
.slideshow-item:nth-child(3),
.slideshow-item:nth-child(3) img {
  animation-delay: 10s;
}

.slideshow-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  animation: moving-vertically 18s infinite;
}

@keyframes move {
    12.5%{
      opacity: 1;
      pointer-events: auto;
  }
  25%{
    opacity: 1;
    pointer-events: auto;
  }
  37.5%{
    opacity: 0;
  }
}
@keyframes scale {
    30%{
      transform: scale(0.3);
  }
}


</style>
</head>
<body>
<h1>Пейзажи Марса</h1>

<div class="slideshow">
    <div class="slideshow-item">
        <img src="img/mars1.jpg" alt="">
        <div class="slideshow-item-text">

        </div>
    </div>
    <div class="slideshow-item">
        <img src="img/mars2.jpg" alt="">
        <div class="slideshow-item-text">

        </div>
    </div>
    <div class="slideshow-item">
        <img src="img/mars3.jpg" alt="">
        <div class="slideshow-item-text">

        </div>
    </div>
</div>
</body>
</html>
"""



if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
